package com.klef.jfsd.springboot.project.model;

public class BookingTimetable {
	
}
